import 'core-js/es/array/sort';
import 'core-js/es/object/keys';
/**
 * Polyfill adding function
 */
export declare function polyfill(): void;
