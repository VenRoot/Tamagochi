export interface Clonable<T> {
    clone(): T;
}
