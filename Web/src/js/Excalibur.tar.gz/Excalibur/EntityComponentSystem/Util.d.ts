export declare const buildTypeKey: (types: readonly string[]) => string;
