/**
 * Whether or not the browser can play this file as HTML5 Audio
 */
export declare function canPlayFile(file: string): boolean;
