export declare enum WheelDeltaMode {
    Pixel = "Pixel",
    Line = "Line",
    Page = "Page"
}
