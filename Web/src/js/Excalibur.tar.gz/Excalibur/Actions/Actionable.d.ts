import { ActionContext } from './ActionContext';
export interface Actionable {
    actions: ActionContext;
}
