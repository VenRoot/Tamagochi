export declare class GraphicsDiagnostics {
    static DrawCallCount: number;
    static DrawnImagesCount: number;
    static clear(): void;
}
