export declare enum ColorBlindnessMode {
    Protanope = "Protanope",
    Deuteranope = "Deuteranope",
    Tritanope = "Tritanope"
}
